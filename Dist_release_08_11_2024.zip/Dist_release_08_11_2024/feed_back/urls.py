from django.urls import path

from feed_back.reports import GenerateReportView
from feed_back.views import CaseCreateView, CaseListView, CaseDetailView, CaseStatusUpdateView, CaseCommentsView, \
    CaseToWorkUpdateView, CaseSubjectListView, CaseSubjectDetailView, DepartmentListView

urlpatterns = [
    path('create/', CaseCreateView.as_view(), name='create'),
    path('tasks/', CaseListView.as_view(), name='task_feedback_list'),

    path('cases/<int:case_id>/', CaseDetailView.as_view(), name='case-detail'),
    path('cases/<int:case_id>/update/', CaseStatusUpdateView.as_view(), name='case-status-update'),
    path('cases/<int:case_id>/comments/', CaseCommentsView.as_view(), name='case-comments'),

    path('cases/to_work/<int:case_id>/', CaseToWorkUpdateView.as_view(), name='case-status-update'),

    path('report/download/', GenerateReportView.as_view(), name='generate_report'),

    path('case-subjects/', CaseSubjectListView.as_view(), name='case_subject_list'),
    path('case-subjects/<int:pk>/', CaseSubjectDetailView.as_view(), name='case_subject_detail'),
    path('departments/', DepartmentListView.as_view(), name='department_list'),
]