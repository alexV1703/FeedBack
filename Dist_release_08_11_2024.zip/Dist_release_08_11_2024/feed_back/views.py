from django.db.models import Q
from django.utils.timezone import now
from rest_framework.generics import ListAPIView, get_object_or_404
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from users.models import Division, Department
from users.pagination import CustomPagination
from .models import Case, CaseSubject, CaseComment
from .serializers import CaseSerializer, DivisionSerializer, CaseSubjectSerializer, CaseListSerializer, \
    CommentSerializer, CaseDetailSerializer, CaseStatusUpdateSerializer, DepartmentSerializer


class CaseCreateView(APIView):

    def get(self, request):
        serializer_form = CaseSerializer()
        divisions = Division.objects.all()
        case_subjects = CaseSubject.objects.all()
        serializer_division = DivisionSerializer(divisions, many=True)
        serializer_case_subjects = CaseSubjectSerializer(case_subjects, many=True)
        return Response({'divisions': serializer_division.data, "form": serializer_form.data, "case_subjects": serializer_case_subjects.data})


    def post(self, request):
        data = request.data.copy()
        data['created_by_user'] = request.user.id

        serializer = CaseSerializer(data=data)
        # Проверяем валидность данных
        if serializer.is_valid():
            serializer.save()  # Сохраняем новую задачу в базу данных
            case = Case.objects.get(id=serializer.data['id'])
            case.case_number = serializer.data['id']
            case.save()
            data = {
                'id': serializer.data['id'],
                "message": "Данные добавлены",
            }
            return Response(data, status=status.HTTP_201_CREATED)

        # Возвращаем ошибки, если данные не валидны
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class TaskFeedbackPagination(PageNumberPagination):
    page_size = 10  # Set the page size
    page_size_query_param = 'page_size'
    max_page_size = 100

    def get_paginated_response(self, data):
        return Response({
            'count': self.page.paginator.count,  # Total number of items
            'total_pages': self.page.paginator.num_pages,  # Total number of pages
            'current_page': self.page.number,  # Current page number
            'next': self.get_next_link(),
            'previous': self.get_previous_link(),
            'results': data,  # The actual data items
        })


class CaseListView(APIView):
    serializer_class = CaseListSerializer
    pagination_class = TaskFeedbackPagination
    permission_classes = [IsAuthenticated]  # Ensure the user is authenticated

    def post(self, request, *args, **kwargs):
        print(request.data)
        user = self.request.user
        user_roles = [role.name.lower() for role in user.roles.all()]

        # Получаем параметры пагинации из тела запроса
        page = request.data.get('page', 1)
        page_size = request.data.get('page_size', 10)

        # Получаем параметр поиска из тела запроса
        search_query = request.data.get('search', '').strip()

        # Базовый queryset
        if 'admin' in user_roles or 'supervisor' in user_roles:
            queryset = Case.objects.filter(status__in=['open', 'in_progress'])
        elif 'responsible' in user_roles:
            #queryset = Case.objects.filter(department__in=user.departments.all(), status__in=['open', 'in_progress'])
            queryset = Case.objects.filter(case_subject__department__in=user.departments.all(), status__in=['open', 'in_progress'])
        else:
            queryset = Case.objects.none()

        # Если есть поисковый запрос, фильтруем по нескольким полям
        if search_query:
            queryset = queryset.filter(
                Q(organization_name__icontains=search_query) |
                Q(tax_registration_number__icontains=search_query) |
                Q(full_name__icontains=search_query) |
                Q(reg_number__icontains=search_query) |
                Q(case_subject__name__icontains=search_query) |
                Q(issue_description__icontains=search_query)  # Добавьте другие поля для поиска, если нужно
            )

        # Пагинация
        # Создаем объект пагинации
        paginator = self.pagination_class()
        # Устанавливаем параметры запроса для пэйджинатора вручную
        request.query_params._mutable = True  # Делаем query_params изменяемым
        request.query_params['page'] = page
        request.query_params['page_size'] = page_size

        # Получаем текущую страницу
        result_page = paginator.paginate_queryset(queryset, request)

        # Сериализуем данные
        serializer = self.serializer_class(result_page, many=True)

        # Возвращаем ответ с пагинацией
        return paginator.get_paginated_response(serializer.data)


class CaseDetailView(APIView):
    """
    Представление для получения деталей дела по ID
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, case_id):
        try:
            # Получаем дело по ID
            case = Case.objects.get(id=case_id)
            # Сериализуем данные
            serializer = CaseDetailSerializer(case)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Case.DoesNotExist:
            return Response({"error": "Дело не найдено"}, status=status.HTTP_404_NOT_FOUND)


class CaseStatusUpdateView(APIView):
    """
    Представление для обновления статуса дела
    """
    permission_classes = [IsAuthenticated]

    def patch(self, request, case_id):
        try:
            # Получаем дело по ID
            case = Case.objects.get(id=case_id)

            # Проверка доступа к делу (например, только ответственный может его изменить)
            # if case.responsible_user != request.user:
            #     return Response({"error": "У вас нет доступа к изменению этого дела."}, status=status.HTTP_403_FORBIDDEN)

            # Сериализуем данные
            serializer = CaseStatusUpdateSerializer(case, data=request.data, partial=True)
            if serializer.is_valid():
                print(serializer.validated_data)
                serializer.save()
                print(serializer.data)
                case = Case.objects.get(id=serializer.data['id'])
                case.closed_at = now()
                case.closed_by_user = request.user
                case.save()
                msg = {
                    "ok": "ok",
                    "message": f"Обращение: {serializer.data['id']} успешно закрыто"
                }
                return Response(msg, status=status.HTTP_200_OK)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Case.DoesNotExist:
            return Response({"error": "Дело не найдено"}, status=status.HTTP_404_NOT_FOUND)


class CaseCommentsView(APIView):
    """
    Представление для получения и добавления комментариев к делу
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, case_id):
        try:
            # Получаем дело по ID
            case = Case.objects.get(id=case_id)
            # Получаем все комментарии по данному делу
            comments = CaseComment.objects.filter(case=case)
            serializer = CommentSerializer(comments, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Case.DoesNotExist:
            return Response({"error": "Дело не найдено"}, status=status.HTTP_404_NOT_FOUND)

    def post(self, request, case_id):
        try:
            # Получаем дело по ID
            case = Case.objects.get(id=case_id)
            # Создаем новый комментарий
            serializer = CommentSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save(case=case, created_by=request.user)  # Устанавливаем дело и автора комментария
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Case.DoesNotExist:
            return Response({"error": "Дело не найдено"}, status=status.HTTP_404_NOT_FOUND)


class CaseToWorkUpdateView(APIView):
    def patch(self, request, case_id):
        try:
            # Получаем дело по ID
            case = Case.objects.get(id=case_id)
            if case.status.lower() == 'closed':
                msg = {
                    "message": "Дело уже закрыто"
                }
                return Response(msg, status=status.HTTP_200_OK)

            user = request.user

            # Если задача ещё не в работе
            if not case.is_taken_in_work:
                case.is_taken_in_work = True
                case.assigned_user = user
                case.status = 'in_progress'
                case.assigned_at = now()
                case.save()
                msg = {
                    "ok":"ok",
                    "message": f"Задача {case.id} взята в работу",
                }
            else:
                # Если задача в работе за этим человеком
                if case.assigned_user == user:
                    case.is_taken_in_work = False
                    case.assigned_user = None
                    case.status = 'open'
                    case.assigned_at = None
                    case.save()
                    msg = {
                        "ok": "ok",
                        "message": f"Задача {case.id} возвращена в работу",
                    }
                else:
                    msg = {
                        "message": f"Вы не немоте взять в работу, в данный момент ей занимается {case.assigned_user.email}",
                    }
            return Response(msg, status=status.HTTP_200_OK)
        except Case.DoesNotExist:
            return Response({"error": "Дело не найдено"}, status=status.HTTP_404_NOT_FOUND)


class CaseSubjectListView(APIView):
    """
    APIView для получения списка тем заявок с пагинацией и создания новой заявки.
    """

    def get(self, request):
        """
        Метод GET для получения списка тем заявок с пагинацией.
        """
        case_subjects = CaseSubject.objects.all()  # Получаем все темы заявок
        paginator = CustomPagination()
        result_page = paginator.paginate_queryset(case_subjects, request)

        serializer = CaseSubjectSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)

    def post(self, request):
        """
        Метод POST для создания новой темы заявки.
        """
        serializer = CaseSubjectSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CaseSubjectDetailView(APIView):
    """
    APIView для получения, обновления и удаления конкретной темы заявки по id.
    """

    def get_object(self, pk):
        """
        Метод для получения объекта CaseSubject по pk.
        """
        return get_object_or_404(CaseSubject, pk=pk)

    def get(self, request, pk):
        """
        Метод GET для получения конкретной темы заявки по id.
        """
        case_subject = self.get_object(pk)
        serializer = CaseSubjectSerializer(case_subject)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def patch(self, request, pk):
        """
        Метод PATCH для частичного обновления темы заявки по id.
        """
        case_subject = self.get_object(pk)
        serializer = CaseSubjectSerializer(case_subject, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        """
        Метод DELETE для удаления темы заявки по id.
        """
        case_subject = self.get_object(pk)
        case_subject.delete()
        return Response({"message": "Case subject deleted successfully"}, status=status.HTTP_204_NO_CONTENT)


class DepartmentListView(APIView):
    """
    APIView для получения списка департаментов.
    """

    def get(self, request):
        """
        Метод GET для получения всех департаментов.
        """
        departments = Department.objects.all()
        serializer = DepartmentSerializer(departments, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)