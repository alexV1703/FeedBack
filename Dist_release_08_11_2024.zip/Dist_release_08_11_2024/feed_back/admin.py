from django.contrib import admin

from feed_back.models import Case, CaseSubject, District
from users.models import User, Division, Department, Role

# Register your models here.
admin.site.register(Case)
admin.site.register(CaseSubject)
admin.site.register(District)