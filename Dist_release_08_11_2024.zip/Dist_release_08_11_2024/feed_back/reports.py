from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font
from django.http import HttpResponse
from rest_framework.views import APIView
from .models import Case  # Импорт вашей модели Case


class GenerateReportView(APIView):
    def post(self, request):
        user = request.user
        user_roles = [role.name.lower() for role in user.roles.all()]

        # Фильтрация данных в зависимости от ролей пользователя
        if 'admin' in user_roles or 'supervisor' in user_roles:
            queryset = Case.objects.filter(status__in=['open', 'in_progress'])
        elif 'responsible' in user_roles:
            queryset = Case.objects.filter(department__in=user.departments.all(), status__in=['open', 'in_progress'])
        else:
            queryset = Case.objects.none()

        # Создаем новую книгу
        wb = Workbook()
        ws = wb.active
        ws.title = 'Отчет'

        # Определение полей и заголовков отчета
        columns = [
            {'header': 'Номер заявки', 'field': 'id'},
            {'header': 'Статус', 'field': 'status', 'translation': self.get_status_translation},
            {'header': 'Создатель', 'field': 'created_by_user.email'},
            {'header': 'Кто взял в работу', 'field': 'assigned_user.email'},
            {'header': 'Тематика', 'field': 'case_subject.name'},
            {'header': 'Дата создания', 'field': 'created_at', 'format': lambda x: x.strftime('%Y-%m-%d')},
            {'header': 'Описание', 'field': 'issue_description'}
        ]

        # Добавляем шапку отчета
        for col_num, col_data in enumerate(columns, 1):
            col_letter = get_column_letter(col_num)
            ws[f'{col_letter}1'] = col_data['header']
            ws[f'{col_letter}1'].font = Font(bold=True)

        # Добавляем данные в отчет
        for row_num, case in enumerate(queryset, 2):
            for col_num, col_data in enumerate(columns, 1):
                col_letter = get_column_letter(col_num)

                # Получаем значение поля из case
                value = self.get_case_field_value(case, col_data['field'])

                # Применяем перевод или форматирование, если указано
                if 'translation' in col_data:
                    value = col_data['translation'](value)
                elif 'format' in col_data:
                    value = col_data['format'](value)

                ws[f'{col_letter}{row_num}'] = value

        # Автоматическая установка ширины столбцов
        for col_num in range(1, len(columns) + 1):
            col_letter = get_column_letter(col_num)
            max_length = max(len(str(cell.value)) for cell in ws[col_letter])
            ws.column_dimensions[col_letter].width = max_length + 5

        # Формируем ответ с файлом
        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        )
        response['Content-Disposition'] = 'attachment; filename=report.xlsx'

        # Сохраняем книгу в ответ
        wb.save(response)

        return response

    def get_status_translation(self, status):
        """Переводит статус на русский язык."""
        status_translations = {
            "open": "Открыта",
            "closed": "Закрыта",
            "in_progress": "Взята в работу"
        }
        return status_translations.get(status, status)

    def get_case_field_value(self, case, field):
        """Получает значение поля из case с поддержкой вложенных атрибутов."""
        fields = field.split('.')
        value = case
        for f in fields:
            value = getattr(value, f, None)
            if value is None:
                return ''
        return value
