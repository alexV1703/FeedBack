from rest_framework import serializers

from users.models import Division, Department
from users.serializers import DepartmentSerializer
from .models import Case, CaseSubject, CaseComment


class CaseSerializer(serializers.ModelSerializer):
    department = serializers.SerializerMethodField()

    def get_department(self, obj):
        return obj.case_subject.department.name

    class Meta:
        model = Case
        fields = '__all__'  # Здесь указываются все поля модели


class DivisionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Division
        fields = ['id', 'name', 'is_active']


class CaseSubjectSerializer(serializers.ModelSerializer):
    department_objects = DepartmentSerializer(source='department', read_only=True)
    department_id = serializers.PrimaryKeyRelatedField(
        queryset=Department.objects.all(), source='department', write_only=True
    )


    class Meta:
        model = CaseSubject
        fields = ['id',
                  'name',
                  'district',
                  'department',
                  'department_id',
                  'description',
                  'department_objects'

                  ]

class CaseListSerializer(serializers.ModelSerializer):
    department = serializers.SerializerMethodField()
    name_case_subject = serializers.SerializerMethodField()
    priority = serializers.SerializerMethodField()
    created_at = serializers.DateTimeField(format="%d.%m.%Y %H:%M")
    status = serializers.SerializerMethodField()

    def get_priority(self, obj):
        if obj.priority == 1:
            return 'Низкий'
        elif obj.priority == 2:
            return 'Средний'
        elif obj.priority == 3:
            return 'Высокий'

    def get_status(self, obj):
        if obj.status == "open":
            return 'Открыта'
        elif obj.status == "closed":
            return 'Закрыта'
        elif obj.status == "in_progress":
            return 'Взята в работу'

    def get_department(self, obj):
        return obj.case_subject.department.name

    def get_name_case_subject(self, obj):
        return obj.case_subject.name


    class Meta:
        model = Case
        fields = [
            'id',
            'organization_name',
            'created_at',
            'name_case_subject',
            'department',
            'priority',
            'status',
            'reg_number',
        ]

class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = CaseComment
        fields = '__all__'


class CaseDetailSerializer(serializers.ModelSerializer):
    assigned_at = serializers.DateTimeField(format="%d.%m.%Y %H:%M")
    created_at = serializers.DateTimeField(format="%d.%m.%Y %H:%M")
    callback_date = serializers.DateTimeField(format="%d.%m.%Y %H:%M")
    due_date = serializers.DateTimeField(format="%d.%m.%Y %H:%M")
    status = serializers.SerializerMethodField()
    created_by_user = serializers.SerializerMethodField()
    assigned_user = serializers.SerializerMethodField()
    division = serializers.SerializerMethodField()
    case_subject = serializers.SerializerMethodField()
    permission_close_task= serializers.SerializerMethodField()

    def get_created_by_user(self, obj):
        return f"{obj.created_by_user.last_name} {obj.created_by_user.first_name} {obj.created_by_user.middle_name}"

    def get_assigned_user(self, obj):
        try:
            return f"{obj.assigned_user.last_name} {obj.assigned_user.first_name} {obj.assigned_user.middle_name}"
        except AttributeError:
            return "-"
    def get_division(self, obj):
        return f"{obj.division.name}"

    def get_case_subject(self, obj):
        return f"{obj.case_subject.name}"

    def get_status(self, obj):
        if obj.status == "open":
            return 'Открыта'
        elif obj.status == "closed":
            return 'Закрыта'
        elif obj.status == "in_progress":
            return 'Взята в работу'

    def get_permission_close_task(self, obj):
        print(obj.status)
        if obj.status == "closed":
            return False
        else:
            if obj.is_taken_in_work:
                if obj.assigned_user == obj.created_by_user:
                    return True
                else: return False
            return True

    class Meta:
        model = Case
        # {"id":25,"case_number":25,"priority":2,"created_at":"2024-09-26T15:00:37.027792+03:00","closed_at":null,"assigned_at":"2024-09-26T15:00:44.641146+03:00",
        # "status":"in_progress","is_overdue":false,"is_taken_in_work":true,"full_name":"123","phone_number":"123","tax_registration_number":"123","reg_number":"000000000000",
        # "organization_name":"123","issue_description":"1233","response_text":null,"callback_date":"2024-09-26T00:00:00+03:00","due_date":null,"created_by_user":1,"closed_by_user":null,"assigned_user":1,"division":2,"case_subject":1}
        fields = [
            "id",
            "case_number",
            "priority",
            "created_at",
            "closed_at",
            "assigned_at",
            "status",
            "is_overdue",
            "is_taken_in_work",
            "full_name",
            "phone_number",
            "tax_registration_number",
            "reg_number",
            "organization_name",
            "issue_description",
            "response_text",
            "callback_date",
            "due_date",
            "created_by_user",
            "closed_by_user",
            "assigned_user",
            "division",
            "case_subject",
            "permission_close_task",


        ]


class CaseStatusUpdateSerializer(serializers.ModelSerializer):
    read_only = 'id'
    class Meta:
        model = Case
        fields = [
            'id',
            'response_text',
            'status'
        ]

class CaseToWorkUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Case
        fields = [
            'assigned_user',
            'is_taken_in_work',
        ]

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['id', 'name']  # Указываем поля, которые нужно включить
