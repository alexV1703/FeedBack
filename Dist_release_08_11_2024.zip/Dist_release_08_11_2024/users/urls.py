from django.urls import path
from .views import MyTokenObtainPairView, LoginView, UserRegistrationView, DivisionListView, DivisionView, \
    DepartmentListView, DepartmentDetailView, UserListView, UserDetailView, CustomTokenRefreshView, RoleListView, \
    RoleDetailView, UserCreateView, UserProfileView
from rest_framework_simplejwt.views import TokenRefreshView

urlpatterns = [
    path('register/', UserRegistrationView.as_view(), name='register'),  # Маршрут для регистрации
    path('admin/create-user/', UserCreateView.as_view(), name='create_user'),  # URL для создания пользователя

    path('login/', LoginView.as_view(), name='login'),  # Вход с email и паролем
    path('api/token/', MyTokenObtainPairView.as_view(), name='token_obtain_pair'),  # Получение токенов
    path('token/refresh/', CustomTokenRefreshView.as_view(), name='token_refresh'),  # Обновление токена


    path('divisions_all/', DivisionListView.as_view(), name='division-list'),
    path('divisions/', DivisionView.as_view(), name='division'),


    path('departments_all/', DepartmentListView.as_view(), name='department-list'),  # Выдача списка всех отделов
    path('departments/', DepartmentDetailView.as_view(), name='department-detail'),  # CRUD операции для отделов

    path('users_all/', UserListView.as_view(), name='user-list'),  # Получение списка всех пользователей
    path('user/<int:id>', UserDetailView.as_view(), name='user-detail'),  # CRUD операции для пользователей

    path('roles_all/', RoleListView.as_view(), name='role-list'),  # Получение списка всех ролей
    path('role/', RoleDetailView.as_view(), name='role-detail'),  # CRUD операции для ролей

    path('profile/', UserProfileView.as_view(), name='user-profile'),


]
