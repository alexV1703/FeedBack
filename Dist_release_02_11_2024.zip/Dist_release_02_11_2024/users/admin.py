from django.contrib import admin

from users.models import User, Division, Department, Role

# Register your models here.
admin.site.register(User)
admin.site.register(Division)

admin.site.register(Department)
admin.site.register(Role)