from django.contrib.auth.hashers import make_password
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework.permissions import AllowAny, IsAdminUser
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from django.contrib.auth import authenticate

from users.init_roles_and_superuser import create_super_user
from users.models import Division, Department, User, Role
from users.pagination import CustomPagination
from users.serializers import UserRegistrationSerializer, DivisionSerializer, DepartmentSerializer, UserSerializer, \
    RoleSerializer, UserSerializerFromAdmin


# Создаем представление для получения JWT-токена
class MyTokenObtainPairView(TokenObtainPairView):
    permission_classes = (AllowAny,)


class CustomTokenRefreshView(TokenRefreshView):
    """
    Кастомное представление для обновления токена, которое возвращает новый access_token.
    """

    def post(self, request, *args, **kwargs):
        print(request.data)
        serializer = self.get_serializer(data=request.data)

        try:
            serializer.is_valid(raise_exception=True)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        # Получаем новый refresh и access токены
        print(serializer.validated_data.get('access'))
        access_token = serializer.validated_data.get('access')
        refresh_token = request.data.get('refresh')

        return Response({
            'refresh_token': refresh_token,  # Возвращаем обновленный refresh_token
            'access_token': access_token  # Возвращаем новый access_token
        }, status=status.HTTP_200_OK)

# Дополнительное представление для авторизации
class LoginView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')

        # Проверяем, указаны ли email и пароль
        if not email or not password:
            return Response({"error": "Необходимо указать email и пароль."}, status=status.HTTP_400_BAD_REQUEST)

        # Аутентификация пользователя
        user = authenticate(request, email=email, password=password)

        if user is not None:
            if not user.is_active:
                return Response({"error": "Пользователь заблокирован."}, status=status.HTTP_400_BAD_REQUEST)
            try:
                # Генерация токенов через RefreshToken
                refresh = RefreshToken.for_user(user)

                # Получаем все роли пользователя и формируем их в виде списка
                roles = [{"id": role.id, "name": role.name.lower()} for role in user.roles.all()]

                return Response({
                    'refresh_token': str(refresh),
                    'access_token': str(refresh.access_token),
                    'gender': user.gender,  # Возвращаем пол
                    'email': user.email,  # Возвращаем email
                    'roles': roles,  # Возвращаем роли пользователя в виде списка объектов
                }, status=status.HTTP_200_OK)
            except ObjectDoesNotExist:
                return Response({"error": "У пользователя нет назначенных ролей."}, status=status.HTTP_404_NOT_FOUND)
        else:
            # Сообщение об ошибке, если неверный email или пароль
            return Response({"error": "Неверный email или пароль."}, status=status.HTTP_400_BAD_REQUEST)

class UserRegistrationView(APIView):
    def post(self, request):
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "User registered successfully."}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

"""ПОДРАЗДЕЛЕНИЯ"""

class DivisionListView(APIView):
    def get(self, request):
        divisions = Division.objects.all()  # Получаем все объекты Division

        # Используем кастомную пагинацию
        paginator = CustomPagination()
        result_page = paginator.paginate_queryset(divisions, request)

        serializer = DivisionSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)

class DivisionView(APIView):
    def get(self, request):
        pk = request.data.get('id')
        if pk:
            try:
                pk = request.data.get('id')
                division = Division.objects.get(pk=pk)
                serializer = DivisionSerializer(division)
                return Response(serializer.data, status=status.HTTP_200_OK)
            except Division.DoesNotExist:
                return Response({"error": "Division not found"}, status=status.HTTP_404_NOT_FOUND)
        else:
            divisions = Division.objects.all()
            serializer = DivisionSerializer(divisions, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = DivisionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request):
        try:
            pk = request.data.get('id')
            division = Division.objects.get(pk=pk)
        except Division.DoesNotExist:
            return Response({"error": "Division not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = DivisionSerializer(division, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        try:
            pk = request.data.get('id')
            division = Division.objects.get(pk=pk)
        except Division.DoesNotExist:
            return Response({"error": "Division not found"}, status=status.HTTP_404_NOT_FOUND)

        division.delete()
        return Response({"message": "Division deleted successfully"}, status=status.HTTP_204_NO_CONTENT)

"""Отделы"""


class DepartmentListView(APIView):
    def get(self, request):
        departments = Department.objects.all()  # Получаем все отделы
        paginator = CustomPagination()
        result_page = paginator.paginate_queryset(departments, request)

        serializer = DepartmentSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)


class DepartmentDetailView(APIView):
    def get_object(self, pk):
        try:
            return Department.objects.get(pk=pk)
        except Department.DoesNotExist:
            return None

    def get(self, request):
        pk = request.data.get('id')  # Получаем pk из тела запроса
        department = self.get_object(pk)
        if not department:
            return Response({"error": "Department not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = DepartmentSerializer(department)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        print(request.data)
        serializer = DepartmentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request):
        pk = request.data.get('id')  # Получаем pk из тела запроса
        department = self.get_object(pk)
        if not department:
            return Response({"error": "Department not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = DepartmentSerializer(department, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        pk = request.data.get('id')  # Получаем pk из тела запроса
        department = self.get_object(pk)
        if not department:
            return Response({"error": "Department not found"}, status=status.HTTP_404_NOT_FOUND)

        department.delete()
        return Response({"message": "Department deleted successfully"}, status=status.HTTP_204_NO_CONTENT)

"""Пользователи"""


class UserListView(APIView):
    def post(self, request):
        #create_super_user()
        # Получаем параметры из запроса
        search = request.data.get('search', '')  # Поисковый запрос
        role_ids = request.data.get('role', [])  # Роли
        is_active = request.data.get('is_active', 'all')  # Активные/Неактивные пользователи

        # Фильтрация пользователей
        users = User.objects.all()

        # Фильтрация по активности
        if is_active==True:
            users = users.filter(is_active=True)
        elif is_active == False:
            users = users.filter(is_active=False)
        else:
            pass

        # Фильтрация по ролям, если указаны роли
        if role_ids:
            users = users.filter(roles__id__in=role_ids)
        # Поиск по имени или email
        if search:
            users = users.filter(
                Q(first_name__icontains=search) | Q(last_name__icontains=search) | Q(email__icontains=search)
            )

        # Пагинация
        paginator = CustomPagination()

        result_page = paginator.paginate_queryset(users, request)

        # Сериализация данных
        serializer = UserSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)


class UserDetailView(APIView):
    def get_object(self, pk):
        try:
            return User.objects.get(pk=pk)
        except User.DoesNotExist:
            return None

    def get(self, request, id):

        #pk = request.data.get('id')  # Получаем pk из данных запроса
        user = self.get_object(id)
        if not user:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = UserSerializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        print(request.data)
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, id):
        print(request.data)
        user = self.get_object(id)
        if not user:
            return Response({"error": "Пользователь не найден"}, status=status.HTTP_404_NOT_FOUND)

        # Проверка и установка нового пароля
        new_password = request.data.get('new_password')
        if new_password:
            user.set_password(new_password)  # Безопасно устанавливаем пароль на объекте пользователя
            user.save(update_fields=["password"])  # Сохраняем только поле пароля

        # Удаляем поле password из request.data перед передачей данных в сериализатор
        request_data = request.data.copy()
        request_data.pop('password', None)

        serializer = UserSerializer(user, data=request_data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        pk = request.data.get('id')  # Получаем pk из данных запроса
        user = self.get_object(pk)
        if not user:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

        user.delete()
        return Response({"message": "User deleted successfully"}, status=status.HTTP_204_NO_CONTENT)
"""Роли"""


class RoleListView(APIView):
    def post(self, request):
        role = Role.objects.all()  # Получаем всех пользователей
        paginator = CustomPagination()
        result_page = paginator.paginate_queryset(role, request)
        # print(" USER Result page type:", type(result_page))  # Должен быть <class 'list'>, что ожидаемо после пагинации
        print(" USER Roles before serialization:", result_page)

        serializer = RoleSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)

class RoleDetailView(APIView):
    def get_object(self, pk):
        try:
            return Role.objects.get(pk=pk)
        except Role.DoesNotExist:
            return None

    def get(self, request):
        pk = request.data.get('id')  # Получаем pk из данных запроса
        role = self.get_object(pk)
        if not role:
            return Response({"error": "Role not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = RoleSerializer(role)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = RoleSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request):
        pk = request.data.get('id')  # Получаем pk из данных запроса
        role = self.get_object(pk)
        if not role:
            return Response({"error": "Role not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = RoleSerializer(role, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        pk = request.data.get('id')  # Получаем pk из данных запроса
        role = self.get_object(pk)
        if not role:
            return Response({"error": "Role not found"}, status=status.HTTP_404_NOT_FOUND)

        role.delete()
        return Response({"message": "Role deleted successfully"}, status=status.HTTP_204_NO_CONTENT)


class UserCreateView(APIView):
    permission_classes = [IsAdminUser]  # Ограничиваем доступ только администраторам

    def post(self, request):
        # Получаем данные из запроса
        data = request.data

        # Проверяем, передан ли пароль, и хешируем его
        # if 'password' in data:
        #     data['password'] = make_password(data['password'])
        print(data['password'])

        # Создаем сериализатор
        serializer = UserSerializerFromAdmin(data=data)

        # Проверяем валидность данных
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Пользователь успешно создан", "data": serializer.data},
                            status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)