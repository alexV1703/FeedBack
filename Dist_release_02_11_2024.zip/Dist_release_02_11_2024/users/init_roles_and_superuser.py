import os
import django
from django.contrib.auth import get_user_model

# Убедитесь, что Django использует правильные настройки
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'FeedBackGlobal.settings')

# Инициализация Django перед импортом моделей
django.setup()

# Теперь можно импортировать модель роли из приложения
from users.models import Role


def create_default_roles():
    roles = [
        {"name": "admin", "help_text": "Администратор"},
        {"name": "supervisor", "help_text": "Супервизор"},
        {"name": "responsible", "help_text": "Ответственный"},
        {"name": "controller", "help_text": "Контролёр"},
        {"name": "operator", "help_text": "Оператор"},
        {"name": "user", "help_text": "Обычный пользователь"}
    ]

    for role_data in roles:
        role, created = Role.objects.get_or_create(name=role_data['name'],
                                                   defaults={"help_text": role_data['help_text']})
        if created:
            print(f"Роль '{role.name}' успешно создана.")
        else:
            print(f"Роль '{role.name}' уже существует.")


def create_super_user():
    User = get_user_model()

    # Замените на нужные значения

    users = ["admin1@example.com", "adm@adm.ru"]
    # for i in range(1, 50):
    #     users.append(f"user{i}@example.com")
    password = "sfr2024"

    for u in users:
        if not User.objects.filter(email=u).exists():
            superuser = User.objects.create_superuser(email=u, password=password)
            admin_role, _ = Role.objects.get_or_create(name="admin")
            superuser.roles.add(admin_role)
            superuser.save()

            print(f"Суперпользователь с email '{u}' успешно создан.")
        else:
            print(f"Суперпользователь с email '{u}' уже существует.")


if __name__ == '__main__':
    create_default_roles()
    create_super_user()
