from django.contrib.auth import get_user_model

from users.models import Division, Department, Role

User = get_user_model()

from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password


class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])

    class Meta:
        model = User
        fields = ['email', 'first_name', 'middle_name', 'last_name', 'password', 'phone']

    def create(self, validated_data):
        user = User.objects.create(
            email=validated_data['email'],
            first_name=validated_data['first_name'],
            last_name=validated_data['last_name'],
            middle_name=validated_data.get('middle_name', None),  # Отчество — необязательное поле
            phone=validated_data.get('phone', None),  # Телефон — необязательное поле
        )
        user.set_password(validated_data['password'])  # Устанавливаем пароль (с хешированием)
        user.save()
        return user


class DivisionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Division
        fields = ['id', 'name', 'is_active']


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ['id', 'name', 'help_text', 'is_active']


class DepartmentSerializer(serializers.ModelSerializer):
    division = serializers.PrimaryKeyRelatedField(
        queryset=Division.objects.all())  # Вложенный сериализатор для передачи объекта направления
    division_object = DivisionSerializer(source='division', read_only=True)

    class Meta:
        model = Department
        fields = ['id', 'name', 'division', 'division_object', 'is_active']

    def create(self, validated_data):
        division = validated_data.pop('division')  # division уже является объектом Division
        department = Department.objects.create(division=division, **validated_data)
        return department

    def update(self, instance, validated_data):
        division = validated_data.pop('division', None)
        if division:
            instance.division = division  # Здесь уже передается объект Division

        instance.name = validated_data.get('name', instance.name)
        instance.is_active = validated_data.get('is_active', instance.is_active)
        instance.save()
        return instance


"""Пользователи"""


class UserSerializer(serializers.ModelSerializer):
    departments_objects = DepartmentSerializer(source='departments', read_only=True, many=True)
    roles_objects = serializers.SerializerMethodField()
    departments = serializers.PrimaryKeyRelatedField(queryset=Department.objects.all(), many=True)
    roles_a = RoleSerializer(source='roles', read_only=True, many=True)

    def get_roles_objects(self, obj):
        roles = obj.roles.all()  # Получаем все роли пользователя
        if roles.exists():
            return ', '.join([role.help_text for role in roles])  # Возвращаем роли через запятую
        return "Роли не назначены"  # Если ролей нет

    class Meta:
        model = User
        fields = [
            'id', 'email', 'first_name', 'last_name', 'middle_name', 'phone', 'gender',
            'is_active', 'is_staff', 'registered_at', 'last_login',
            'departments', 'departments_objects', 'roles', 'roles_a', 'roles_objects'
        ]

    def create(self, validated_data):
        departments = validated_data.pop('departments', [])
        roles = validated_data.pop('roles', [])
        user = User.objects.create(**validated_data)
        user.departments.set(departments)  # Устанавливаем отделы
        user.roles.set(roles)  # Устанавливаем роли
        user.set_password(validated_data['password'])  # Устанавливаем пароль
        user.save()
        return user

    def update(self, instance, validated_data):
        departments = validated_data.pop('departments', None)
        roles = validated_data.pop('roles', None)

        if departments is not None:
            instance.departments.set(departments)
        if roles is not None:
            instance.roles.set(roles)

        instance.first_name = validated_data.get('first_name', instance.first_name)
        instance.last_name = validated_data.get('last_name', instance.last_name)
        instance.middle_name = validated_data.get('middle_name', instance.middle_name)
        instance.phone = validated_data.get('phone', instance.phone)
        instance.gender = validated_data.get('gender', instance.gender)
        instance.is_active = validated_data.get('is_active', instance.is_active)
        instance.is_staff = validated_data.get('is_staff', instance.is_staff)

        if 'password' in validated_data:
            instance.set_password(validated_data['password'])

        instance.save()
        return instance


class UserSerializerFromAdmin(serializers.ModelSerializer):
    # Поля ролей и отделов необходимо сериализовать
    roles = serializers.PrimaryKeyRelatedField(queryset=Role.objects.all(), many=True)
    departments = serializers.PrimaryKeyRelatedField(queryset=Department.objects.all(), many=True)
    roles_objects = serializers.SerializerMethodField()

    def get_roles_objects(self, obj):
        roles = obj.roles.all()  # Получаем все роли пользователя
        if roles.exists():
            return ', '.join([role.help_text for role in roles])  # Возвращаем роли через запятую
        return "Роли не назначены"  # Если ролей нет

    class Meta:
        model = User
        fields = [
            'id',
            'email',
            'first_name',
            'middle_name',
            'last_name',
            'gender',
            'phone',
            'is_active',
            'roles',
            'departments',
            'password',
            'roles_objects'
        ]
        extra_kwargs = {
            'password': {'write_only': True, 'validators': [validate_password]},
        }

    def create(self, validated_data):
        # Извлечение ролей и отделов перед созданием пользователя
        roles = validated_data.pop('roles', [])
        departments = validated_data.pop('departments', [])

        # Создаем пользователя без пароля
        user = User.objects.create(**validated_data)

        # Устанавливаем пароль после создания
        user.set_password(validated_data['password'])
        user.save()
        # Устанавливаем роли и отделы
        user.roles.set(roles)
        user.departments.set(departments)

        user.save()
        return user

    def update(self, instance, validated_data):
        # Извлечение ролей и отделов перед обновлением пользователя
        roles = validated_data.pop('roles', None)
        departments = validated_data.pop('departments', None)

        # Обновление пароля, если он был передан
        password = validated_data.pop('password', None)
        print("Обновляю пароль")
        print(password)
        if password:
            instance.set_password(password)  # Устанавливаем пароль корректно

        # Обновление других полей пользователя
        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        # Обновление ролей и отделов, если переданы
        if roles is not None:
            instance.roles.set(roles)
        if departments is not None:
            instance.departments.set(departments)

        instance.save()
        return instance