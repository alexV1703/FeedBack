from django.db import models
from django.utils.timezone import now
from users.models import User, Department, Division

class District(models.Model):
    """Модель для районов"""
    name = models.CharField(max_length=100, unique=True)  # Название района
    is_active = models.BooleanField(default=True)  # Флаг активности

    def __str__(self):
        return f"{self.name} (Активный: {self.is_active})"


class CaseSubject(models.Model):
    """Модель для тем заявок"""
    name = models.CharField(max_length=200, unique=True)  # Название темы заявки
    description = models.TextField(blank=True, null=True)  # Описание темы (опционально)

    # Связь с районом (опционально)
    district = models.ForeignKey(District, on_delete=models.SET_NULL, blank=True, null=True)

    # Связь с ответственным отделом
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, blank=True, null=True)

    def __str__(self):
        return f"{self.name} (Отдел: {self.department.name if self.department else 'None'}, Район: {self.district.name if self.district else 'None'})"


class CasePriority(models.IntegerChoices):
    LOW = 1, 'Низкий'
    MEDIUM = 2, 'Средний'
    HIGH = 3, 'Высокий'

class CaseStatus(models.TextChoices):
    OPEN = 'open', 'Открыта'
    CLOSED = 'closed', 'Закрыта'
    IN_PROGRESS = 'in_progress', 'Взята в работу'

class Case(models.Model):
    """Модель для хранения информации о заявках"""
    case_number = models.IntegerField(blank=True, null=True)  # Уникальный номер заявки
    priority = models.IntegerField(choices=CasePriority.choices, default=CasePriority.MEDIUM)  # Приоритет заявки

    # Информация о пользователях
    created_by_user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="created_cases")  # Кто создал
    closed_by_user = models.ForeignKey(User, on_delete=models.SET_NULL, blank=True, null=True, related_name="closed_cases")  # Кто закрыл
    assigned_user = models.ForeignKey(User, on_delete=models.SET_NULL, blank=True, null=True, related_name="assigned_cases")  # Кто взял в работу

    # Даты
    created_at = models.DateTimeField(default=now)  # Дата создания
    closed_at = models.DateTimeField(blank=True, null=True)  # Дата закрытия
    assigned_at = models.DateTimeField(blank=True, null=True)  # Дата взятия в работу

    # Статус заявки
    status = models.CharField(max_length=50, choices=CaseStatus.choices, default=CaseStatus.OPEN)  # Статус заявки
    is_overdue = models.BooleanField(default=False)  # Просрочена ли заявка
    is_taken_in_work = models.BooleanField(default=False)  # Взята ли заявка в работу

    # Связь с таблицей подразделений
    division = models.ForeignKey(Division, on_delete=models.CASCADE)  # Внешний ключ на подразделение

    # Тема заявки
    case_subject = models.ForeignKey(CaseSubject, on_delete=models.CASCADE)  # Тема заявки

    # Дополнительная информация
    full_name = models.CharField(max_length=200)  # Полное имя клиента
    phone_number = models.CharField(max_length=20)  # Телефон клиента
    tax_registration_number = models.CharField(max_length=100)  # ИНН
    reg_number = models.CharField(max_length=20, default="000-000-000000")
    organization_name = models.CharField(max_length=500)  # Название организации
    issue_description = models.TextField()  # Вопрос или описание обращения
    response_text = models.TextField(blank=True, null=True)  # Ответ на обращение
    callback_date = models.DateTimeField(blank=True, null=True)  # Дата обратного звонка
    due_date = models.DateTimeField(blank=True, null=True)  # Дата выполнения заявки

    def __str__(self):
        return f"{self.case_number} (Статус: {self.status}, Подразделение: {self.division.name})"


class CaseHistory(models.Model):
    """Модель для хранения истории изменений и действий над заявками"""
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name="history")  # Связь с заявкой
    user = models.ForeignKey(User, on_delete=models.SET_NULL, blank=True, null=True)  # Пользователь, совершивший действие
    action = models.CharField(max_length=255)  # Описание действия
    timestamp = models.DateTimeField(default=now)  # Время действия

    def __str__(self):
        return f"История {self.case.case_number} (Действие: {self.action}, Время: {self.timestamp})"


class CaseComment(models.Model):
    """Модель для хранения комментариев к заявкам"""
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name="comments")  # Связь с заявкой
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Пользователь, оставивший комментарий
    comment = models.TextField()  # Текст комментария
    created_at = models.DateTimeField(default=now)  # Дата создания комментария

    def __str__(self):
        return f"Комментарий к {self.case.case_number} (Пользователь: {self.user.email}, Комментарий: {self.comment[:20]})"
