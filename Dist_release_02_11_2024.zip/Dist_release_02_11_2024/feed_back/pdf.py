from django.http import HttpResponse
from django.template.loader import render_to_string
from weasyprint import HTML
from rest_framework.views import APIView
from .models import Case

class GenerateCasePDFView(APIView):
    def get(self, request, case_id):
        # Получаем заявку по id
        try:
            case = Case.objects.get(pk=case_id)
        except Case.DoesNotExist:
            return HttpResponse("Заявка не найдена", status=404)

        # Данные, которые будут переданы в шаблон HTML
        context = {
            'case': case,
            'priority_mapping': {1: 'Низкий', 2: 'Средний', 3: 'Высокий'},
        }

        # Генерация HTML на основе шаблона
        html_string = render_to_string('case_pdf_template.html', context)

        # Создание PDF из HTML
        html = HTML(string=html_string)
        pdf_file = html.write_pdf()

        # Отправляем PDF в качестве ответа
        response = HttpResponse(pdf_file, content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="case_{case.id}.pdf"'

        return response
